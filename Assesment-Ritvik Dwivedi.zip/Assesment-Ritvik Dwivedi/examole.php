<?php
// Validate form fields
$full_name = $_POST['full_name'];
$phone_number = $_POST['phone_number'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];
if (empty($full_name) || empty($phone_number) || empty($email) || empty($subject) || empty($message)) {
    die("All fields are mandatory.");
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format.");
}
// Database connection
$servername = "localhost";
$username = "postgres";
$password = "123456";
$dbname = "postgres";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
// Insert data into database
$stmt = $conn->prepare("INSERT INTO contact_form (full_name, phone_number, email, subject, message, ip_address, timestamp) VALUES (?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("ssssss", $full_name, $phone_number, $email, $subject, $message, $_SERVER['REMOTE_ADDR']);
$stmt->execute();
$stmt->close();
// Send email notification
$to = "eashandwivedi134@gmail.com.com";
$subject = "New Contact Form Submission";
$message = "Name: $full_name\nPhone: $phone_number\nEmail: $email\nSubject: $subject\nMessage: $message";
$headers = "From: $email";
mail($to, $subject, $message, $headers);
$conn->close();
echo "Form submitted successfully!";
?>